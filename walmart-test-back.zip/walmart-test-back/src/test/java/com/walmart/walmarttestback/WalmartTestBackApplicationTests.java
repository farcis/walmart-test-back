package com.walmart.walmarttestback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalmartTestBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
