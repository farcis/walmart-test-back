package com.walmart.walmarttestback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalmartTestBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalmartTestBackApplication.class, args);
	}

}
